<!DOCTYPE html>
<html>

<head>
    <title>Laporan Keseluruhan Proyek</title>
    <style>
        body {
            font-family: sans-serif;
            font-size: 11px;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
        }

        .header h1 {
            margin: 0;
            font-size: 16px;
            text-transform: uppercase;
        }

        .project-section {
            margin-bottom: 30px;
            page-break-inside: avoid;
        }

        .project-title {
            font-size: 14px;
            font-weight: bold;
            background-color: #e5e7eb;
            padding: 8px;
            margin-bottom: 10px;
        }

        .meta-table {
            width: 100%;
            margin-bottom: 10px;
        }

        .meta-table td {
            padding: 2px;
        }

        table.data {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }

        table.data th,
        table.data td {
            border: 1px solid #ccc;
            padding: 4px;
        }

        table.data th {
            background-color: #f9fafb;
            text-align: left;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .badge-price {
            background-color: #eee;
            padding: 1px 4px;
            border-radius: 3px;
            font-weight: bold;
            font-size: 10px;
        }

        .page-break {
            page-break-after: always;
        }

        /* Styles untuk Grid Nota */
        .receipt-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }

        .receipt-item {
            display: inline-block;
            width: 30%;
            margin-bottom: 20px;
            vertical-align: top;
            border: 1px solid #ddd;
            padding: 8px;
            background-color: #fff;
        }

        .receipt-img {
            width: 100%;
            height: auto;
            max-height: 200px;
            object-fit: contain;
            border: 1px solid #eee;
            margin: 5px 0;
        }
    </style>
</head>

<body>

    <div class="header">
        <h1>Laporan Keseluruhan Proyek</h1>
        <p>PT. JAYA KARYA KONTRUKSI</p>
        <p>Dicetak pada: <?php echo e($generatedAt); ?></p>
    </div>

    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="project-section">
            <div class="project-title"><?php echo e($project['name']); ?>

                (<?php echo e($project['status'] == 'ongoing' ? 'Berjalan' : 'Selesai'); ?>)</div>

            <table class="meta-table">
                <tr>
                    <td width="15%">Durasi</td>
                    <td width="2%">:</td>
                    <td><?php echo e($project['start_date']); ?> s/d <?php echo e($project['end_date']); ?> (<?php echo e($project['duration']); ?>)</td>
                </tr>
                <tr>
                    <td>Total Pengeluaran</td>
                    <td>:</td>
                    <td><strong>Rp <?php echo e(number_format($project['total_expense'], 0, ',', '.')); ?></strong></td>
                </tr>
            </table>

            <h4>Rincian Pengeluaran:</h4>
            <table class="data">
                <thead>
                    <tr>
                        <th width="30%">Periode (Minggu/Hari)</th>
                        <th>Rincian Item & Harga Satuan</th>
                        <th width="20%" class="text-right">Total (Rp)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $project['weekly_expenses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weekKey => $weekItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            [$weekNum, $year] = explode('-', $weekKey);
                            $dto = new DateTime();
                            $dto->setISODate($year, $weekNum);
                            $weekStart = $dto->format('d/m/Y');
                            $weekEnd = $dto->modify('+6 days')->format('d/m/Y');
                        ?>
                        
                        <tr style="background-color: #eff6ff;">
                            <td colspan="2"><strong>Minggu ke-<?php echo e($weekNum); ?> (<?php echo e($weekStart); ?> -
                                    <?php echo e($weekEnd); ?>)</strong></td>
                            <td class="text-right">
                                <strong><?php echo e(number_format($weekItems->sum('amount'), 0, ',', '.')); ?></strong></td>
                        </tr>

                        
                        <?php $__currentLoopData = $weekItems->groupBy(fn($i) => $i->transacted_at->format('Y-m-d')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dateKey => $dayItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="padding-left: 20px; vertical-align: top;">
                                    <?php echo e(\Carbon\Carbon::parse($dateKey)->format('d F Y')); ?>

                                </td>
                                <td style="vertical-align: top;">
                                    <ul style="margin: 0; padding-left: 15px;">
                                        <?php $__currentLoopData = $dayItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li style="margin-bottom: 4px;">
                                                <span><?php echo e($item->title); ?></span>
                                                
                                                <span class="badge-price">Rp
                                                    <?php echo e(number_format($item->amount, 0, ',', '.')); ?></span>

                                                <?php if($item->description): ?>
                                                    <br><small style="color: #666;"> - <?php echo e($item->description); ?></small>
                                                <?php endif; ?>

                                                <?php if($withReceipts && $item->receipt_image): ?>
                                                    <br><small style="color: blue;"><i>(Lihat Lampiran Nota)</i></small>
                                                <?php endif; ?>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </td>
                                <td class="text-right" style="vertical-align: top; font-weight: bold;">
                                    <?php echo e(number_format($dayItems->sum('amount'), 0, ',', '.')); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php if($withReceipts): ?>
                <div class="page-break"></div>
                <h3>Lampiran Nota: <?php echo e($project['name']); ?></h3>
                <div class="receipt-grid">
                    <?php $__currentLoopData = $project['expenses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($expense->receipt_image): ?>
                            <div class="receipt-item">
                                <div style="border-bottom: 1px solid #eee; padding-bottom: 5px; margin-bottom: 5px;">
                                    <div style="font-weight: bold; font-size: 11px;"><?php echo e($expense->title); ?></div>
                                    <div style="font-size: 10px; color: #666;">
                                        <?php echo e($expense->transacted_at->format('d F Y')); ?></div>
                                </div>

                                
                                <img src="<?php echo e(public_path('storage/' . $expense->receipt_image)); ?>" class="receipt-img">

                                
                                <div style="text-align: right; font-weight: bold; font-size: 12px; color: #333;">
                                    Rp <?php echo e(number_format($expense->amount, 0, ',', '.')); ?>

                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="page-break"></div>
            <?php endif; ?>
        </div>
        <hr style="border: 0; border-top: 2px dashed #ccc; margin: 30px 0;">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>

</html>
<?php /**PATH C:\Users\Farros\Projects\jkk\panel-bendahara\resources\views/pdf/laporan_keseluruhan.blade.php ENDPATH**/ ?>