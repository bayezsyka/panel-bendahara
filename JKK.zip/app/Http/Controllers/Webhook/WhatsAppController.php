<?php

namespace App\Http\Controllers\Webhook;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;

// Model & Service yang akan kita buat/update di langkah selanjutnya
use App\Models\Mandor;
use App\Models\Project;
use App\Models\Expense;
use App\Services\GeminiReceiptService;

class WhatsAppController extends Controller
{
    /**
     * Handle incoming Webhook from WhatsApp API (Fonnte/WAHA/etc)
     */
    public function handle(Request $request)
    {
        try {
            // --- DEBUGGING: LOG SEMUA DATA ---
            // Ini akan mencetak seluruh isi JSON dari Fonnte ke log
            Log::info("INCOMING MESSAGE:", $request->all());

            $rawSender = $request->input('sender') ?? $request->input('from');
            $sender = $this->formatPhoneNumber($rawSender);
            $message = trim($request->input('message') ?? $request->input('body') ?? '');
            $type = $request->input('type'); // Ambil tipe pesan

            // Cek URL Gambar
            $mediaUrl = $request->input('url') ?? $request->input('file') ?? null;

            // --- DETEKSI ERROR FONNTE ---
            // Jika Fonnte gagal baca gambar (kasus "non-text message")
            if ($message === 'non-text message' && !$mediaUrl) {
                $this->replyWA($sender, "⚠️ Gagal memproses gambar. WhatsApp Bot belum siap/sinkron. Mohon tunggu 5 menit lalu kirim ulang.");
                return response()->json(['status' => 'error', 'reason' => 'fonnte_sync_issue']);
            }

            // --- Logika Utama ---
            $mandor = Mandor::where('whatsapp_number', $sender)->first();

            if (!$mandor) {
                // Jika nomor tidak terdaftar, abaikan atau balas error
                // $this->replyWA($sender, "Nomor Anda tidak terdaftar sebagai Mandor.");
                return response()->json(['status' => 'ignored', 'reason' => 'unregistered']);
            }

            // Cari Proyek Aktif (Ongoing) milik Mandor ini
            $activeProject = $mandor->projects()->where('status', 'ongoing')->first();
            if (!$activeProject) {
                $this->replyWA($sender, "Halo {$mandor->name}, Anda tidak memiliki proyek aktif saat ini.");
                return response()->json(['status' => 'error', 'reason' => 'no_active_project']);
            }

            // 3. Cek Sesi Cache (Apakah sedang menunggu konfirmasi?)
            $sessionKey = 'wa_session_' . $sender;
            $pendingData = Cache::get($sessionKey);

            // --- SKENARIO 1: Mandor Kirim Gambar (Analisis AI) ---
            if ($mediaUrl && !$pendingData) {
                $this->replyWA($sender, "⏳ Sedang menganalisis struk, mohon tunggu...");

                // Download gambar sementara untuk dianalisis
                $tempImageContent = file_get_contents($mediaUrl);
                $base64Image = base64_encode($tempImageContent);

                // Panggil Service Gemini AI
                $gemini = new GeminiReceiptService();
                $result = $gemini->analyzeReceipt($base64Image);

                if (!$result) {
                    $this->replyWA($sender, "❌ Gagal membaca struk. Pastikan foto jelas dan pencahayaan cukup. Silakan kirim ulang.");
                    return response()->json(['status' => 'error', 'reason' => 'ai_failed']);
                }

                // Simpan gambar ke storage public agar bisa diakses nanti
                $fileName = 'receipts/' . Str::random(40) . '.jpg';
                Storage::disk('public')->put($fileName, $tempImageContent);

                // Siapkan data untuk konfirmasi
                $confirmData = [
                    'project_id' => $activeProject->id,
                    'title' => $result['title'] ?? 'Pengeluaran Lainnya',
                    'amount' => $result['amount'] ?? 0,
                    'description' => $result['description'] ?? '-',
                    'transacted_at' => $result['date'] ?? date('Y-m-d'),
                    'receipt_image' => $fileName,
                ];

                // Simpan ke Cache selama 10 menit
                Cache::put($sessionKey, $confirmData, 600);

                // Format Pesan Konfirmasi
                $reply = "✅ *Konfirmasi Laporan Pengeluaran*\n\n" .
                    "Proyek: {$activeProject->name}\n" .
                    "Toko/Judul: *{$confirmData['title']}*\n" .
                    "Tanggal: {$confirmData['transacted_at']}\n" .
                    "Item: {$confirmData['description']}\n" .
                    "Nominal: *Rp " . number_format($confirmData['amount'], 0, ',', '.') . "*\n\n" .
                    "Balas *YA* untuk simpan data.\n" .
                    "Balas *BATAL* untuk membatalkan.";

                $this->replyWA($sender, $reply);
                return response()->json(['status' => 'success', 'action' => 'confirm_request']);
            }

            // --- SKENARIO 2: Konfirmasi (YA / BATAL) ---
            if ($pendingData) {
                if (strtolower($message) === 'ya') {
                    // Simpan ke Database Expense
                    Expense::create([
                        'project_id' => $pendingData['project_id'],
                        'title' => $pendingData['title'],
                        'amount' => $pendingData['amount'],
                        'description' => $pendingData['description'],
                        'transacted_at' => $pendingData['transacted_at'],
                        'receipt_image' => $pendingData['receipt_image'],
                    ]);

                    // Hapus Sesi
                    Cache::forget($sessionKey);

                    $this->replyWA($sender, "✅ Laporan berhasil disimpan! Masuk ke pembukuan bendahara.");
                    return response()->json(['status' => 'success', 'action' => 'saved']);
                } elseif (strtolower($message) === 'batal') {
                    // Hapus file gambar yang sudah terlanjur diupload (opsional, untuk hemat storage)
                    Storage::disk('public')->delete($pendingData['receipt_image']);

                    Cache::forget($sessionKey);
                    $this->replyWA($sender, "🚫 Laporan dibatalkan. Silakan kirim foto baru.");
                    return response()->json(['status' => 'success', 'action' => 'cancelled']);
                } else {
                    $this->replyWA($sender, "Format salah. Balas *YA* untuk simpan atau *BATAL*.");
                }
            }
            // Jika kirim text biasa tanpa sesi (Chatting biasa)
            else if (!$mediaUrl) {
                $this->replyWA($sender, "Halo {$mandor->name}. Silakan kirim *FOTO STRUK/NOTA* untuk input laporan pengeluaran otomatis.");
            }

            return response()->json(['status' => 'success']);
        } catch (\Exception $e) {
            Log::error("WhatsApp Error: " . $e->getMessage());
            return response()->json(['status' => 'error', 'message' => $e->getMessage()], 500);
        }
    }

    /**
     * Helper: Format nomor HP ke format database (misal: 081 -> 6281)
     */
    private function formatPhoneNumber($number)
    {
        // Hapus karakter non-angka
        $number = preg_replace('/[^0-9]/', '', $number);

        // Ubah 08xx jadi 628xx
        if (substr($number, 0, 2) === '08') {
            $number = '62' . substr($number, 1);
        }

        return $number;
    }

    /**
     * Helper: Kirim Pesan Balasan WA
     * Sesuaikan dengan API Provider Anda (Fonnte, WAHA, Twilio, dll)
     */
    private function replyWA($target, $message)
    {
        $token = env('FONNTE_TOKEN'); // Token diambil dari .env

        try {
            /** @var \Illuminate\Http\Client\Response $response */
            $response = Http::withHeaders([
                'Authorization' => $token,
            ])->post('https://api.fonnte.com/send', [
                'target' => $target,
                'message' => $message,
                // 'url' => 'https://link-gambar.com/file.jpg' // Jika ingin kirim gambar
            ]);

            Log::info("Fonnte Response: " . $response->body());
        } catch (\Exception $e) {
            Log::error("Fonnte Error: " . $e->getMessage());
        }
    }
}
