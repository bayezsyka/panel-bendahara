<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Laporan Proyek</title>
    <style>
        body {
            font-family: "Times New Roman", Times, serif;
            font-size: 12px;
            color: #111;
            line-height: 1.4;
        }

        .kop {
            width: 100%;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        .kop-table {
            width: 100%;
            border-collapse: collapse;
        }

        .company {
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .judul {
            text-align: center;
            margin: 14px 0 12px 0;
        }

        .judul .h1 {
            font-size: 14px;
            font-weight: bold;
            text-decoration: underline;
            margin-bottom: 2px;
        }

        .info-box {
            width: 100%;
            margin: 10px 0 14px 0;
            border: 1px solid #000;
            border-collapse: collapse;
        }

        .info-box td {
            padding: 4px 6px;
            border: 1px solid #000;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        .data-table th,
        .data-table td {
            border: 1px solid #000;
            padding: 4px 6px;
            vertical-align: top;
            /* Pastikan teks mulai dari atas */
        }

        .data-table th {
            background-color: #f0f0f0;
            text-align: left;
            font-weight: bold;
        }

        .week-header {
            background-color: #e2e2e2;
            font-weight: bold;
            font-style: italic;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .text-bold {
            font-weight: bold;
        }

        /* Styles untuk Lampiran Grid */
        .page-break {
            page-break-before: always;
        }

        .lampiran-title {
            text-align: center;
            font-size: 14px;
            font-weight: bold;
            text-decoration: underline;
            margin-bottom: 15px;
        }

        .grid-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
        }

        .grid-cell {
            width: 50%;
            padding: 10px;
            border: 1px solid #ddd;
            vertical-align: top;
            height: 400px;
        }

        .grid-meta {
            margin-bottom: 8px;
            font-size: 11px;
            border-bottom: 1px dashed #999;
            padding-bottom: 5px;
        }

        .grid-img-container {
            text-align: center;
            display: block;
        }

        .grid-img {
            max-width: 100%;
            max-height: 280px;
            width: auto;
            height: auto;
            margin: 0 auto;
        }

        .empty-cell {
            border: none;
        }

        /* Style Khusus Item Detail */
        .item-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 10px;
            margin-top: 3px;
        }

        .item-table td {
            border: none;
            /* Hilangkan border tabel dalam */
            padding: 1px 0;
            color: #333;
        }
    </style>
</head>

<body>
    
    <div class="kop">
        <table class="kop-table">
            <tr>
                <td style="width: 15%; text-align:center;">
                    <img src="https://jkk.sangkolo.store/images/logo.png" style="height: 60px;">
                </td>
                <td style="text-align: center;">
                    <div class="company">PT. JAYA KARYA KONTRUKSI</div>
                    <div style="font-size: 11px;">General Contractor & Supplier</div>
                </td>
                <td style="width: 15%;"></td>
            </tr>
        </table>
    </div>

    <div class="judul">
        <div class="h1">LAPORAN KEUANGAN PROYEK</div>
        <div><?php echo e($project->name); ?></div>
    </div>

    
    <table class="info-box">
        <tr>
            <td width="20%" class="text-bold">Nama Proyek</td>
            <td width="30%"><?php echo e($project->name); ?></td>
            <td width="20%" class="text-bold">Status</td>
            <td><?php echo e($project->status == 'ongoing' ? 'Sedang Berjalan' : 'Selesai'); ?></td>
        </tr>
        <tr>
            <td class="text-bold">Mandor</td>
            <td><?php echo e($project->mandor ? $project->mandor->name : '-'); ?></td>
            <td class="text-bold">Lokasi</td>
            <td><?php echo e($project->coordinates ?? '-'); ?></td>
        </tr>
    </table>

    
    <table class="data-table">
        <thead>
            <tr>
                <th width="5%" class="text-center">No</th>
                <th width="15%">Tanggal</th>
                <th>Keterangan & Rincian Item</th> 
                <th width="10%" class="text-center">Ref</th>
                <th width="20%" class="text-right">Jumlah</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $total = 0;
                $currentWeek = null;
            ?>

            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $total += $expense->amount;
                    // Hitung Minggu ke berapa dalam tahun ini
                    $weekNum = \Carbon\Carbon::parse($expense->transacted_at)->isoWeek();
                    $yearNum = \Carbon\Carbon::parse($expense->transacted_at)->format('Y');
                    $weekKey = $yearNum . '-' . $weekNum;
                ?>

                
                <?php if($currentWeek !== $weekKey): ?>
                    <tr>
                        <td colspan="5" class="week-header">
                            Minggu ke-<?php echo e($weekNum); ?> (<?php echo e($yearNum); ?>)
                        </td>
                    </tr>
                    <?php $currentWeek = $weekKey; ?>
                <?php endif; ?>

                <tr>
                    <td class="text-center"><?php echo e($index + 1); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($expense->transacted_at)->format('d/m/Y')); ?></td>
                    <td>
                        
                        <strong><?php echo e($expense->title); ?></strong>

                        
                        <?php if($expense->items && $expense->items->count() > 0): ?>
                            <table class="item-table">
                                <?php $__currentLoopData = $expense->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="width: 50%; padding-left: 8px;">• <?php echo e($item->name); ?></td>
                                        <td style="width: 25%; text-align: right; color: #555;">
                                            <?php echo e($item->quantity); ?> x <?php echo e(number_format($item->price, 0, ',', '.')); ?>

                                        </td>
                                        <td style="width: 25%; text-align: right; font-weight: bold;">
                                            = <?php echo e(number_format($item->total_price, 0, ',', '.')); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        <?php endif; ?>

                        
                        <?php if($expense->description): ?>
                            <div style="margin-top: 4px; font-size: 10px; color: #666; font-style: italic;">
                                Catatan: <?php echo e($expense->description); ?>

                            </div>
                        <?php endif; ?>
                    </td>
                    <td class="text-center"><?php echo e($expense->receipt_image ? 'Ada' : '-'); ?></td>
                    <td class="text-right"><?php echo e(number_format($expense->amount, 0, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="4" class="text-right text-bold">TOTAL PENGELUARAN</td>
                <td class="text-right text-bold">Rp <?php echo e(number_format($total, 0, ',', '.')); ?></td>
            </tr>
        </tfoot>
    </table>

    <div style="margin-top: 10px; font-size: 10px; text-align: right; color: #777;">
        Dicetak otomatis pada: <?php echo e(date('d F Y, H:i')); ?>

    </div>

    
    <?php
        // Filter hanya yang punya gambar
        $expensesWithImages = $expenses->filter(function ($e) {
            return !empty($e->receipt_image) && file_exists(storage_path('app/public/' . $e->receipt_image));
        });
    ?>

    <?php if($expensesWithImages->count() > 0): ?>

        
        <?php $__currentLoopData = $expensesWithImages->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunkIndex => $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="page-break"></div>
            <div class="lampiran-title">LAMPIRAN BUKTI TRANSAKSI (Hal <?php echo e($loop->iteration); ?>)</div>

            <table class="grid-table">
                
                <tr>
                    <?php $__currentLoopData = $chunk->slice(0, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="grid-cell">
                            <div class="grid-meta">
                                <strong><?php echo e(\Carbon\Carbon::parse($expense->transacted_at)->format('d/m/Y')); ?></strong>
                                -
                                <?php echo e($expense->title); ?> (Rp <?php echo e(number_format($expense->amount, 0, ',', '.')); ?>)
                            </div>
                            <div class="grid-img-container">
                                <?php
                                    $path = storage_path('app/public/' . $expense->receipt_image);
                                    $type = pathinfo($path, PATHINFO_EXTENSION);
                                    $data = file_get_contents($path);
                                    $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
                                ?>
                                <img src="<?php echo e($base64); ?>" class="grid-img">
                            </div>
                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if($chunk->slice(0, 2)->count() < 2): ?>
                        <td class="empty-cell"></td>
                    <?php endif; ?>
                </tr>

                
                <?php if($chunk->count() > 2): ?>
                    <tr>
                        <?php $__currentLoopData = $chunk->slice(2, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="grid-cell">
                                <div class="grid-meta">
                                    <strong><?php echo e(\Carbon\Carbon::parse($expense->transacted_at)->format('d/m/Y')); ?></strong>
                                    -
                                    <?php echo e($expense->title); ?> (Rp <?php echo e(number_format($expense->amount, 0, ',', '.')); ?>)
                                </div>
                                <div class="grid-img-container">
                                    <?php
                                        $path = storage_path('app/public/' . $expense->receipt_image);
                                        $type = pathinfo($path, PATHINFO_EXTENSION);
                                        $data = file_get_contents($path);
                                        $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
                                    ?>
                                    <img src="<?php echo e($base64); ?>" class="grid-img">
                                </div>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($chunk->slice(2, 2)->count() < 2): ?>
                            <td class="empty-cell"></td>
                        <?php endif; ?>
                    </tr>
                <?php endif; ?>
            </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>

</body>

</html>
<?php /**PATH C:\Users\Farros\Projects\jkk\panel-bendahara\resources\views/pdf/laporan_proyek.blade.php ENDPATH**/ ?>