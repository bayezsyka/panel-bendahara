<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Laporan Keseluruhan Proyek</title>
    <style>
        body {
            font-family: "Times New Roman", Times, serif;
            font-size: 12px;
            color: #111;
            line-height: 1.4;
        }

        /* Kop Surat Utama */
        .main-header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
        }

        .company-name {
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
        }

        /* Section per Proyek (BAGIAN 1) */
        .project-section {
            margin-bottom: 18px;
            /* penting: JANGAN paksa pindah halaman tiap proyek */
            page-break-after: auto;
            break-after: auto;

            /* bantu supaya tabel proyek tidak “kepotong aneh” */
            page-break-inside: avoid;
            break-inside: avoid;
        }

        .judul {
            text-align: center;
            margin: 10px 0 12px 0;
        }

        .judul .h1 {
            font-size: 14px;
            font-weight: bold;
            text-decoration: underline;
            margin-bottom: 2px;
        }

        /* Info Box */
        .info-box {
            width: 100%;
            margin: 10px 0 14px 0;
            border: 1px solid #000;
            border-collapse: collapse;
        }

        .info-box td {
            padding: 4px 6px;
            border: 1px solid #000;
        }

        /* Data Table */
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        .data-table th,
        .data-table td {
            border: 1px solid #000;
            padding: 4px 6px;
        }

        .data-table th {
            background-color: #f0f0f0;
            text-align: left;
            font-weight: bold;
        }

        /* Highlight Header Pekan */
        .week-header {
            background-color: #e2e2e2;
            font-weight: bold;
            color: #333;
            padding-top: 8px;
            padding-bottom: 8px;
            font-style: italic;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .text-bold {
            font-weight: bold;
        }

        /* Page Break */
        .page-break {
            page-break-before: always;
            break-before: page;
        }

        /* Lampiran */
        .lampiran-title {
            text-align: center;
            font-size: 14px;
            font-weight: bold;
            text-decoration: underline;
            margin: 10px 0 15px 0;
        }

        .grid-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            margin-bottom: 20px;
        }

        .grid-cell {
            width: 50%;
            padding: 10px;
            border: 1px solid #ddd;
            vertical-align: top;
            height: 380px;
        }

        .grid-meta {
            margin-bottom: 8px;
            font-size: 11px;
            border-bottom: 1px dashed #999;
            padding-bottom: 5px;
        }

        .grid-img-container {
            text-align: center;
            display: block;
        }

        .grid-img {
            max-width: 100%;
            max-height: 280px;
            width: auto;
            height: auto;
            margin: 0 auto;
        }

        .empty-cell {
            border: none;
        }
    </style>
</head>

<body>

    
    <div class="main-header">
        <img src="https://jkk.sangkolo.store/images/logo.png" style="height: 50px; margin-bottom: 5px;">
        <div class="company-name">PT. JAYA KARYA KONSTRUKSI</div>
        <div style="font-size: 11px;">LAPORAN KEUANGAN KESELURUHAN PROYEK</div>
        <div style="font-size: 10px; margin-top: 5px;">Dicetak pada: <?php echo e($generatedAt); ?></div>
    </div>

    

    <?php
        $grandTotal = 0;
        foreach ($projects as $p) {
            $grandTotal += $p->expenses->sum('amount');
        }
    ?>

    <table class="info-box" style="margin-top: 0;">
        <tr>
            <td width="30%" class="text-bold">TOTAL SEMUA PROYEK</td>
            <td class="text-bold">Rp <?php echo e(number_format($grandTotal, 0, ',', '.')); ?></td>
        </tr>
        <tr>
            <td class="text-bold">Jumlah Proyek</td>
            <td><?php echo e($projects->count()); ?></td>
        </tr>
    </table>

    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="project-section">

            
            <div class="judul">
                <div class="h1"><?php echo e($project->name); ?></div>
                <div style="font-size: 11px;">
                    Status: <?php echo e($project->status == 'ongoing' ? 'Sedang Berjalan' : 'Selesai'); ?>

                </div>
            </div>

            
            <table class="info-box">
                <tr>
                    <td width="20%" class="text-bold">Mandor</td>
                    <td width="30%"><?php echo e($project->mandor ? $project->mandor->name : '-'); ?></td>
                    <td width="20%" class="text-bold">Lokasi</td>
                    <td><?php echo e($project->coordinates ?? '-'); ?></td>
                </tr>
                <tr>
                    <td class="text-bold">Deskripsi</td>
                    <td colspan="3"><?php echo e($project->description ?? '-'); ?></td>
                </tr>
            </table>

            
            <?php
                $total = 0;
                $currentWeek = null;
            ?>

            <table class="data-table">
                <thead>
                    <tr>
                        <th width="5%" class="text-center">No</th>
                        <th width="15%">Tanggal</th>
                        <th>Keterangan</th>
                        <th width="10%" class="text-center">Ref</th>
                        <th width="20%" class="text-right">Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $project->expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $total += $expense->amount;

                            $dateObj = \Carbon\Carbon::parse($expense->transacted_at);
                            $weekNum = $dateObj->isoWeek();
                            $yearNum = $dateObj->year;
                            $weekKey = $yearNum . '-' . $weekNum;

                            $startOfWeek = $dateObj->copy()->startOfWeek()->format('d M');
                            $endOfWeek = $dateObj->copy()->endOfWeek()->format('d M Y');
                        ?>

                        <?php if($currentWeek !== $weekKey): ?>
                            <tr>
                                <td colspan="5" class="week-header">
                                    Pekan ke-<?php echo e($weekNum); ?> (<?php echo e($startOfWeek); ?> - <?php echo e($endOfWeek); ?>)
                                </td>
                            </tr>
                            <?php $currentWeek = $weekKey; ?>
                        <?php endif; ?>

                        <tr>
                            <td class="text-center"><?php echo e($index + 1); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($expense->transacted_at)->format('d/m/Y')); ?></td>
                            <td>
                                <strong><?php echo e($expense->title); ?></strong>
                                <?php if($expense->description): ?>
                                    <br><span style="font-size: 10px; color: #555;"><?php echo e($expense->description); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center"><?php echo e($expense->receipt_image ? 'Ada' : '-'); ?></td>
                            <td class="text-right"><?php echo e(number_format($expense->amount, 0, ',', '.')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if($project->expenses->isEmpty()): ?>
                        <tr>
                            <td colspan="5" class="text-center" style="padding: 10px;">
                                Belum ada data pengeluaran.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4" class="text-right text-bold">TOTAL PENGELUARAN</td>
                        <td class="text-right text-bold">Rp <?php echo e(number_format($total, 0, ',', '.')); ?></td>
                    </tr>
                </tfoot>
            </table>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    

    <?php
        // cek apakah ada lampiran sama sekali
        $hasAnyAttachment = false;
        foreach ($projects as $p) {
            $cnt = $p->expenses
                ->filter(function ($e) {
                    return !empty($e->receipt_image) && file_exists(storage_path('app/public/' . $e->receipt_image));
                })
                ->count();
            if ($cnt > 0) {
                $hasAnyAttachment = true;
                break;
            }
        }

        $firstLampiranProject = true;
    ?>

    <?php if($hasAnyAttachment): ?>
        
        <div class="page-break"></div>

        <div class="lampiran-title">LAMPIRAN BUKTI TRANSAKSI</div>

        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $expensesWithImages = $project->expenses->filter(function ($e) {
                    return !empty($e->receipt_image) && file_exists(storage_path('app/public/' . $e->receipt_image));
                });
            ?>

            <?php if($expensesWithImages->count() == 0): ?>
                <?php continue; ?>
            <?php endif; ?>

            
            <?php if(!$firstLampiranProject): ?>
                <div class="page-break"></div>
            <?php endif; ?>
            <?php $firstLampiranProject = false; ?>

            <div class="judul" style="margin-top: 0;">
                <div class="h1">Lampiran: <?php echo e($project->name); ?></div>
                <div style="font-size: 11px;">
                    Status: <?php echo e($project->status == 'ongoing' ? 'Sedang Berjalan' : 'Selesai'); ?>

                </div>
            </div>

            
            <?php $__currentLoopData = $expensesWithImages->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunkIndex => $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if($chunkIndex > 0): ?>
                    <div class="page-break"></div>
                <?php endif; ?>

                <div class="lampiran-title" style="font-size: 12px; text-decoration: none;">
                    <?php echo e($project->name); ?> (Hal <?php echo e($chunkIndex + 1); ?>)
                </div>

                <table class="grid-table">
                    <tr>
                        <?php $__currentLoopData = $chunk->slice(0, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="grid-cell">
                                <div class="grid-meta">
                                    <strong><?php echo e(\Carbon\Carbon::parse($expense->transacted_at)->format('d/m/Y')); ?></strong>
                                    - <?php echo e($expense->title); ?> (Rp <?php echo e(number_format($expense->amount, 0, ',', '.')); ?>)
                                </div>
                                <div class="grid-img-container">
                                    <?php
                                        $path = storage_path('app/public/' . $expense->receipt_image);
                                        $type = pathinfo($path, PATHINFO_EXTENSION);
                                        $data = file_get_contents($path);
                                        $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
                                    ?>
                                    <img src="<?php echo e($base64); ?>" class="grid-img">
                                </div>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($chunk->slice(0, 2)->count() < 2): ?>
                            <td class="empty-cell"></td>
                        <?php endif; ?>
                    </tr>

                    <?php if($chunk->count() > 2): ?>
                        <tr>
                            <?php $__currentLoopData = $chunk->slice(2, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="grid-cell">
                                    <div class="grid-meta">
                                        <strong><?php echo e(\Carbon\Carbon::parse($expense->transacted_at)->format('d/m/Y')); ?></strong>
                                        - <?php echo e($expense->title); ?> (Rp
                                        <?php echo e(number_format($expense->amount, 0, ',', '.')); ?>)
                                    </div>
                                    <div class="grid-img-container">
                                        <?php
                                            $path = storage_path('app/public/' . $expense->receipt_image);
                                            $type = pathinfo($path, PATHINFO_EXTENSION);
                                            $data = file_get_contents($path);
                                            $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
                                        ?>
                                        <img src="<?php echo e($base64); ?>" class="grid-img">
                                    </div>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($chunk->slice(2, 2)->count() < 2): ?>
                                <td class="empty-cell"></td>
                            <?php endif; ?>
                        </tr>
                    <?php endif; ?>
                </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

</body>

</html>
<?php /**PATH C:\Users\Farros\Projects\jkk\panel-bendahara\resources\views/pdf/laporan_keseluruhan.blade.php ENDPATH**/ ?>